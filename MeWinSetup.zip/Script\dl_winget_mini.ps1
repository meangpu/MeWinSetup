. "$PSScriptRoot\base_winget.ps1"

$url = "https://gist.githubusercontent.com/meangpu/9327832185f9ef47d1b439345e849037/raw/winget-minimal.json"
Install-WingetPackage -url $url