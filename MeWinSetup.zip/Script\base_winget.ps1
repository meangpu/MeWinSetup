function Get-WinUtilWingetLatest {

if ((Get-Command winget -ErrorAction SilentlyContinue) -eq $null) {
    Write-Host "Winget is not installed. Proceeding with installation..."

    # Download the Microsoft package manager app installer
    $url = "https://github.com/microsoft/winget-cli/releases/latest/download/Microsoft.DesktopAppInstaller_8wekyb3d8bbwe.appxbundle"
    $output = "$env:TEMP\winget.appxbundle"
    Invoke-WebRequest -Uri $url -OutFile $output

    Add-AppxPackage -Path $output
    # Check if installation was successful
    if ((Get-Command winget -ErrorAction SilentlyContinue) -ne $null) {
        Write-Host "Winget installed successfully."
    } else {
        Write-Host "Failed to install Winget."
    }
} else {
    Write-Host "Winget is already installed."
}

}

function Install-WingetPackage {
    param (
        [Parameter(Mandatory=$true)]
        [string]$url
    )

    "==================================="
    "update winget..."
    Get-WinUtilWingetLatest
    "==================================="

    "==================================="
    "download MEANGPU winget package..."

    $output = "$env:userprofile\Downloads\winget.json"
    $start_time = Get-Date

    Invoke-WebRequest -Uri $url -OutFile $output
    "Time taken: $((Get-Date).Subtract($start_time).Milliseconds) miliseconds"

    "==================================="
    "finish download package, installing package"
    winget import $output --accept-package-agreements --accept-source-agreements
    "==================================="

    "==================================="
    "REMOVE package file"
    Remove-Item $output
    "==================================="

    pause
}
