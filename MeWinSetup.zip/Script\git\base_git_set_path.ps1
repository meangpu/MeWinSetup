function SetPath {
    $destinationFolderPath = "D:/Github/"
    Set-Location $destinationFolderPath
    "============================"
    "now-path: $destinationFolderPath"
    "============================"
}
