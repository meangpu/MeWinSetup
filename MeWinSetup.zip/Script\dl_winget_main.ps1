. "$PSScriptRoot\base_winget.ps1"

$url = "https://gist.githubusercontent.com/meangpu/a2159751392c6020ac11f3da752ab845/raw/winget-package-need.json"
Install-WingetPackage -url $url

