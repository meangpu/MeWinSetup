# Define your GitHub username and password
$username = Read-Host -Prompt 'Input your username'
$password = Read-Host -Prompt 'Input the password'

Write-Host "loging in to $username ..."

# Set the GitHub username and password for authentication
git config --global credential.helper store
git config user.name $username
git config user.password $password

Pause