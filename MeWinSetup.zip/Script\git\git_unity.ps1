. "$PSScriptRoot\base_git_set_path.ps1"
SetPath

git clone "https://github.com/meangpu/U.Base3DURP.git"
git clone "https://github.com/meangpu/U.meangpuToolsHub.git"


Pause