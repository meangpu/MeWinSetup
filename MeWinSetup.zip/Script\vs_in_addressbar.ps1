$sourceFolderPath = "$PSScriptRoot\vs"
$destinationFolderPath = "C:/Windows/System32/"

$files = Get-ChildItem -Path $sourceFolderPath -File

"==================================="
"begin moving vs.bat to system32"
"==================================="
foreach ($file in $files) {
    $destinationPath = Join-Path -Path $destinationFolderPath -ChildPath $file.Name
    Copy-Item -Path $file.FullName -Destination $destinationPath
}

"==================================="
"FINISH moving!"
"==================================="
pause