. "$PSScriptRoot\base_git_set_path.ps1"
SetPath

git clone "https://github.com/meangpu/AutoHotkey.git"
git clone "https://github.com/meangpu/backup-program-setting.git"
git clone "https://github.com/meangpu/font.git"
git clone "https://github.com/meangpu/Obsidian.git"

Pause