"==================================="
"open debloat script"
Invoke-WebRequest -useb https://christitus.com/win | Invoke-Expression
"==================================="