"==================================="
"open debloat script"
iwr -useb https://christitus.com/win | iex
"==================================="